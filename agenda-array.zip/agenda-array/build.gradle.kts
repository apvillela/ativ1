plugins {
    id("java")
    id("application")
}

group = "ads.esd"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

application {
    mainClass = "vetor.ex3.Main"
}

tasks.named<JavaExec>("run") {
    standardInput = System.`in`
}
